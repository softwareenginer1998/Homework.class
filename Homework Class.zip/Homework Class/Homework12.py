class Businessman:
    def __init__(self, name, number_of_project):
        self.name = name
        self.number_of_projects = number_of_project
        self.profit = {}

    def add_profit(self, project_name, amount_of_profit):
        self.profit[project_name] = int(amount_of_profit)

    def total_profit(self):
        total_profit = sum(self.profit.values())
        return total_profit

    def good_businessman(self):
        if self.total_profit() > 5000000:
            print("The Best ")
        else:
            print("Not good at business")

businessman1 = Businessman("Sardor", 4)
businessman1.add_profit("Project 1", "200000")
businessman1.good_businessman()
