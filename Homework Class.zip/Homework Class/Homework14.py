class Sportsman:
    def __init__(self, name, type_of_sport):
        self.name = name
        self.type_of_sport = type_of_sport
        self.prize = {}

    def add_prize(self, prize_name, amount_of_prize):
        self.prize[prize_name] = amount_of_prize

    def total_prizes(self):
        total_prize = sum(self.prize.values())
        print(f"The total prize: {total_prize}")
        return total_prize

    def star_sportsman(self):
        if self.total_prizes() > 5:
            print("Good at sport")
        else:
            print("Not bad  at sport")

sportsman1 = Sportsman("Magnus", "Chess")
sportsman1.add_prize("Title Tuesday", 31)
sportsman1.total_prizes()
sportsman1.star_sportsman()