class Artist:
    def __init__(self, name, genre):
        self.name = name
        self.genre = genre
        self.creations = {}

    def add_creation(self, creation_name, number):
        self.creations[creation_name] = number

    def total_creations(self):
        total_creation = sum(self.creations.values())
        print(f"Total creations: {total_creation}")
        return total_creation

    def artist(self):
        if self.total_creations() > 20:
            print("The best artist")
        else:
            print("Ordinary artist")

artist1 = Artist("Leanardo Davinchi", "painting")
artist1.add_creation("The scream", 31)
artist1.add_creation("In the hunt", 31)

artist1.artist()
