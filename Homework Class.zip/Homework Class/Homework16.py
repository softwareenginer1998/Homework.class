class Car:
    def __init__(self, name, color, company, country):
        self.name = name
        self. color = color
        self.company = company
        self.country = country

    def start(self):
        print(f"{self.name} started")

    def stop(self):
        print(f"{self.name} stopped")

    def __str__(self):
        return f"""
Name: {self.name}
Color: {self.color}
Company: {self.company}
Country: {self.country}
"""

class SportsCar(Car):
    def __init__(self, name, color, company, country, model, speed):
        super().__init__(name, color, company, country)
        self.modul = model
        self.speed = speed

    def accelerate(self):
        print(f"{self.name} is going at{self.speed}km/h")


class Truck(Car):
    def __init__(self, name, color, company, country, model, capacity):
        super().__init__(name, color, company, country)
        self.modul = model
        self.capacity = capacity

    def load_cargo(self):
        print(f"{self.name} have load capacity for {self.capacity} t")


sport_car1 = SportsCar("Ferrari", "Black", "Exor N.V", "Italy", "SF90", "340")
truck1 =Truck("Volvo", "Light grey", "Volvo cars", "Sweden", "S90", 20)

sport_car1.start()
sport_car1.stop()
sport_car1.accelerate()

truck1.start()
truck1.stop()
truck1.load_cargo()