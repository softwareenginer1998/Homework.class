class Kutubxona:
    def __init__(self, nom):
        self.nom=nom
        self.kitoblar=[]

    def kitob_qosh(self,nom):
        self.kitoblar.append(nom)

    def malumotlarni_chop_et(self):

        print(f"Kitoblar: {self.kitoblar}")

kitob=Kutubxona("Al-Farg'oniy")
kitob.kitob_qosh("Dam")
kitob.kitob_qosh("LOL")
kitob.malumotlarni_chop_et()