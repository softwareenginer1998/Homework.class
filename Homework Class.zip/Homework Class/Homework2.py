class Avtomobil:
    def __init__(self, model, yil, tezlik=0):
        self.model=model
        self.yil=yil
        self.tezlik=tezlik
    def tezlikni_oshir(self,qadam):
        self.tezlik+=qadam
    def  malumotni_chop_et(self):
        print(f"Model: {self.model}")
        print(f'Yili: {self.yil}')
        print(f'Tezligi: {self.tezlik} Km/soat')
avto=Avtomobil("BMW X5", "2015")
avto.tezlikni_oshir(200)
avto.malumotni_chop_et()