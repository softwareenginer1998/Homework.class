class Competition:
    def __init__(self, name, location):
        self.name = name
        self.location = location
        self.participants = []

    def add_participan(self, participant_name):
        self.participants.append(participant_name)

    def print_information(self):
        print(f"Competition name: {self.name}\nLocation: {self.location}\n Participants: {self.participants}")
competition1 = Competition("Quiz", "Najot Ta'lim")
competition1.add_participan("Asadbek")
competition1.print_information()