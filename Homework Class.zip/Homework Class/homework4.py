class Dokon:
    def __init__(self,nom,manzil):
        self.nom=nom
        self.manzil=manzil
        self.mahsulotlar={}
    def mahsulot_qosh(self,mahsulot_nomi, narx):
        self.mahsulotlar[mahsulot_nomi] = narx
    def malumotni_chop_et(self):
        print(f"Dokon nomi: {self.nom}")
        print(f"Manzili: {self.manzil}")
        print(f"mahsulotlar: {self.mahsulotlar}")
shop=Dokon("Korzinka","Fargona")
shop.mahsulot_qosh('Olma',"5000")
shop.malumotni_chop_et()