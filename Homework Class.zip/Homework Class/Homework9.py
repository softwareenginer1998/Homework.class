class University:
    def __init__(self, name, address):
        self.name = name
        self.address = address
        self.students = {}

    def add_student(self, student_name, student_year):
        self.students[student_name] = student_year

    def print_information(self):
        print(f"University's name: {self.name}")
        print(f"Address: {self.address}")
        print(f"Student's name and university year:")
        for name, year in self.students.items():
            print(f"{name}: {year}th year")

university1 = University("Kaist", "Korea, Seul")
university1.add_student("Farhodjon", 2)
university1.print_information()