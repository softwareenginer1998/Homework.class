class Football:
    def __init__(self, name, country, leauge, stadium, ticket_price):
        self.name = name
        self.country = country
        self.leauge = leauge
        self.stadium = stadium
        self.players = {}
        self.ticket_price = ticket_price
        self.ticket_sold = 0
        self.capacity = 100000
    def add_player(self, player_name, player_number):
        self.players[player_name] = player_number

    def print_information(self):
        print(f"Club's name: {self.name}\nClub's country: {self.country}\nClub's leauge: {self.leauge}\nClub's stadium name: {self.stadium}\nName of players:")
        for player, number in self.players.items():
            print(f"{player}: {number}")

    def buying_tickets(self, number_of_tickets):
        if self.capacity < number_of_tickets + self.ticket_sold:
            print("All tickets sold")

        else:
            total_cost = self.ticket_price * number_of_tickets
            self.ticket_sold += number_of_tickets
            print(f"{number_of_tickets} tickets will be ${total_cost}")

club1 = Football("Atletiko", "Spain", "La Liga", "Bones Ayres", 2500)
club1.add_player("Backham", 11)
club1.add_player("Ronaldo", 7)
club1.print_information()
club1.buying_tickets(2)