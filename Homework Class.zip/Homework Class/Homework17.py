class Game:
    def __init__(self, name, company, number):
        self.name = name
        self.company = company
        self.number = number
        self.available = True


class GameClub(Game):
    def __init__(self, name, company, number, club_name):
        super().__init__(name, company, number)
        self.club_name = club_name
        self.games = {}

    def add_game(self, name, number):
        self.games[name] = number

    def buying_game(self, number, price):
        if number in self.games.values() and self.available:
            print(f"You bought {self.name} for ${price}")
        else:
            print(f"{number} did not found")

    def available_games(self):
        print(f"\n\nAll Games:\n\nName: {self.name}\nCompany: {self.company}\nNumber: {self.number}")
        print("Later added games")
        for name, number in self.games.items():
            print(f"{name}: {number}")

game1 = GameClub("GTA 5", "APPLE", 15000, "Joker")
game1.add_game("The last of us", 35000)
game1.add_game("Asphalt", 4000)

game1.buying_game(3243, 345)
game1.available_games()