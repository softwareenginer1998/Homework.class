class StudentClub:
    def __init__(self, name, students_number):
        self.name = name
        self.stu_number = students_number
        self.event = {}

    def add_event(self, event_name, event_number):
        self.event[event_name] = event_number

    def total_events(self):
        total_events = sum(self.event.values())
        return total_events

    def active_event(self):
        if self.total_events() > 10:
            print("Good value event")
        else:
            print("Bad value event")

club1 = StudentClub("Future leaders of USA", 22)
club1.add_event("CLub", 12)
club1.total_events()
club1.active_event()