class Company:
    def __init__(self, name, field):
        self.name = name
        self.field = field
        self.employees = {}
    def add_employee(self, employee_name, employee_position):
        self.employees[employee_name] = employee_position

    def print_information(self):
        print(f"Company name: {self.name}\nCompany field: {self.field}\nEmployees: {self.employees}")

company1 = Company("Stiv Jobs", "Apple company")
company1.add_employee("John Uik", "Manager")
company1.print_information()