class Employee:
    def __init__(self, name, position, salary):
        self.name = name
        self.position = position
        self.salary = salary
        self.bonus = {}

    def add_bonus(self, month, amount):
        self.bonus[month] = amount

    def total_salary(self):
        total_bonus = sum(self.bonus.values())
        total_salary = self.salary + total_bonus
        print(f"The total salary of {self.name} is {total_salary}")

    def good_employee(self):
        if self.salary > 100000:
            print(f"{self.name} ")
        else:
            print(f"{self.name} ")

employee1 = Employee("Adhamjon", "CEO", 1500000)
employee1.add_bonus("December", 110000)
employee1.total_salary()
employee1.good_employee()