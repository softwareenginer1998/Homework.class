
class Menejer:
    def __init__(self, ism, bolim):
        self.ism=ism
        self.bolim=bolim
        self.xodimlar=[]
    def XodimQoshish(self,ism):
        self.xodimlar.append(ism)
    def Xodimlarni_chop_et(self):
        for xodim in self.xodimlar:
            print(xodim)
menejer=Menejer("Ali","Savdo")
menejer.XodimQoshish("vali")
menejer.XodimQoshish("sodiq")
menejer.Xodimlarni_chop_et()


