class Restaurant:
    def __init__(self, name, address):
        self.name = name
        self.address = address
        self.menu = {}
    def add_dish(self, dish_name, dish_price):
        self.menu[dish_name] = dish_price

    def print_dishes(self):
        print(f"Reataurant's name: {self.name}")
        print(f"Address: {self.address}")
        for name, price in self.menu.items():
            print(f"Dish name: {name}: price: ${price}")
restaurant1 = Restaurant("Sulton Ahmed", "Fargona, Ozbekiston")
restaurant1.add_dish("Steak", 80)

restaurant1.print_dishes()